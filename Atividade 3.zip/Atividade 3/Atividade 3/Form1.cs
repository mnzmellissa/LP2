﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                // receber valor
                double peso = double.Parse(txtPeso.Text);
                double altura = double.Parse(txtAlt.Text);

                // calc imc
                double imc = peso / (altura * altura);

                // classific imc
                string classificacao = GetClassificacao(imc);
                txtIMC.Text = $"{imc:F2}";
                txtClassific.Text = classificacao;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao calcular o IMC. Verifique se os valores inseridos são válidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetClassificacao(double imc)
        {
            if (imc < 18.5)
            {
                return "Magreza";
            }
            else if (imc < 25)
            {
                return "Normal";
            }
            else if (imc < 30)
            {
                return "Sobrepeso";
            }
            else
            {
                return "Obesidade";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            // limpar
            txtPeso.Text = "";
            txtAlt.Text = "";
            txtIMC.Text = "";

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            // fechar
            this.Close();
        }

        private void txtClassific_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
