﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace PContato0030482323036
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try 
            {
                conexao = new SqlConnection("incluir string da conexao da minha maquina");
                conexao.Open(); 
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Erro ao carregar banco de dados" + ex.Message);
            }   
        }

        private void cadastroDeContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContato frm1 = new frmContato();
            frm1.MdiParent = this;
            frm1.WindowState = FormWindowState.Maximized;
            frm1.Show();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobre frm2 = new frmSobre();
            frm2.MdiParent = this;
            frm2.WindowState = FormWindowState.Maximized;
            frm2.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
