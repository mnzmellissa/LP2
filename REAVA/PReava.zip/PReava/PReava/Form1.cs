﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava
{
    public partial class frmMatrizes : Form
    {
        public frmMatrizes()
        {
            InitializeComponent();
        }


        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] matrizA = new double[10];
            double[] matrizB = new double[10];

            Random random = new Random();
            for (int i = 0; i < matrizA.Length; i++)
            {
                matrizA[i] = random.NextDouble() * 100;
            }

            for (int i = 0; i < matrizB.Length; i++)
            {
                if (i % 2 == 0)
                {
                    matrizB[i] = matrizA[i] * 4;
                }
                else
                {
                    matrizB[i] = matrizA[i] + 4;
                }

            }

            for (int i = 0; i < matrizA.Length; i++)
            {
                listBox1.Items.Add($"A[{i}] = {matrizA[i]:F2} B[{i}] = {matrizB[i]:F2}");
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

