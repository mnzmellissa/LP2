﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum1.Text, out int numero1) || !int.TryParse(txtNum2.Text, out int numero2))

            {
                MessageBox.Show("Por favor, insira apenas números inteiros.");
                return;
            }

            if (numero1 >= numero2)
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo.");
                return;
            }

            Random random = new Random();
            int numeroSorteado = random.Next(numero1, numero2 + 1);
            MessageBox.Show($"O número sorteado é: {numeroSorteado}");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
