﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCont_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int i = 0;
            while (i < rtb1.Text.Length)
            {
                if (char.IsNumber(rtb1.Text[i]))
                {
                    contador++;
                }
                i++;
            }
            MessageBox.Show($"Existem {contador} números no texto.");
        }

        private void btnCaracter_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rtb1.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rtb1.Text[i]))
                {
                    MessageBox.Show($"O primeiro caractere em branco está na posição {i + 1}.");
                    break;
                }
            }
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in rtb1.Text)
            {
                if (char.IsLetter(c))
                {
                    contador++;
                }
            }
            MessageBox.Show($"Existem {contador} caracteres alfabéticos.");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
