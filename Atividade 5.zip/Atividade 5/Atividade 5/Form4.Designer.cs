﻿namespace Ptestemetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtb1 = new System.Windows.Forms.RichTextBox();
            this.btnCont = new System.Windows.Forms.Button();
            this.btnCaracter = new System.Windows.Forms.Button();
            this.btnAlfabeticos = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtb1
            // 
            this.rtb1.Location = new System.Drawing.Point(296, 116);
            this.rtb1.Name = "rtb1";
            this.rtb1.Size = new System.Drawing.Size(252, 96);
            this.rtb1.TabIndex = 0;
            this.rtb1.Text = "";
            // 
            // btnCont
            // 
            this.btnCont.Location = new System.Drawing.Point(296, 247);
            this.btnCont.Name = "btnCont";
            this.btnCont.Size = new System.Drawing.Size(252, 30);
            this.btnCont.TabIndex = 1;
            this.btnCont.Text = "Contagem de caracteres numericos";
            this.btnCont.UseVisualStyleBackColor = true;
            this.btnCont.Click += new System.EventHandler(this.btnCont_Click);
            // 
            // btnCaracter
            // 
            this.btnCaracter.Location = new System.Drawing.Point(296, 283);
            this.btnCaracter.Name = "btnCaracter";
            this.btnCaracter.Size = new System.Drawing.Size(252, 27);
            this.btnCaracter.TabIndex = 2;
            this.btnCaracter.Text = "Primeiro caracter em branco";
            this.btnCaracter.UseVisualStyleBackColor = true;
            this.btnCaracter.Click += new System.EventHandler(this.btnCaracter_Click);
            // 
            // btnAlfabeticos
            // 
            this.btnAlfabeticos.Location = new System.Drawing.Point(296, 316);
            this.btnAlfabeticos.Name = "btnAlfabeticos";
            this.btnAlfabeticos.Size = new System.Drawing.Size(252, 30);
            this.btnAlfabeticos.TabIndex = 3;
            this.btnAlfabeticos.Text = "Quantidade de caracteres alfabeticos";
            this.btnAlfabeticos.UseVisualStyleBackColor = true;
            this.btnAlfabeticos.Click += new System.EventHandler(this.btnAlfabeticos_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.RosyBrown;
            this.btnSair.Location = new System.Drawing.Point(815, 12);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(57, 25);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 454);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnAlfabeticos);
            this.Controls.Add(this.btnCaracter);
            this.Controls.Add(this.btnCont);
            this.Controls.Add(this.rtb1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmExercicio4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtb1;
        private System.Windows.Forms.Button btnCont;
        private System.Windows.Forms.Button btnCaracter;
        private System.Windows.Forms.Button btnAlfabeticos;
        private System.Windows.Forms.Button btnSair;
    }
}